<template>
    <div>
        <a4-page>
            <template slot="main1">
                <div>jqsk</div>
        <top-contact>fghtgt</top-contact>
            </template>
        </a4-page>
        
    </div>
</template>
<script>
import a4Page from '@/components/common/a4Page.vue'
import topContact from '@/components/common/topContact.vue'
export default {
    components: {
        a4Page,
        topContact
    }
}
</script>
