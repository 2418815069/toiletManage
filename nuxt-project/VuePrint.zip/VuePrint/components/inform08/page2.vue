<template>
    <div>
        <a4-page>
        </a4-page>
        
    </div>
</template>
<script>
import a4Page from '@/components/common/a4Page.vue'
export default {
    components: {
        a4Page,
    }
}
</script>
