<template>
    <div>
        <div>
            <div class="content letterfont">尊敬的客户：</div>
            <div class="content">您好！</div>
            <div class="content letterfont">
            首先，感It您在百忙之中拨冗拆阅这封信，也感It您一直以来给予中美联泰大都会人寿 保险有限公司的关注与支持。
            </div>
            <div class="content letterfont">
            我们非常重视您这样的老客户，希望能继续得到您的支持。但遗憾的是，您的保单状态现已中止。我们怀着极大的诚意，向您发出“倦鸟归巢”的邀请，希望您能办理复效手续。若您在此信寄出日期的一个月内，拨打我公司的客服电话：400-818-8168(人工接听时间：周一至周日8:30-20:30。其他时间敬请留言），将会有专人帮助您办理复效手续。若您此前在我公司登记的身份证明文件已过有效期，可一并拨打客服电话进行更新。
            </div>
            <div class="content letterfont">
            若在此信函发出的一个月内，我公司没有接到您的复效申请，您的保单则将因长时间不办理复效而保单终止。我公司将进行退费整理。若您的保单有退款，则将返回至您最后一次扣款成功银行账号内。退费到账有短信通知您。若您已联系我公司并申请复效成功，则此信函仅作为温馨提醒。
            </div>
            <div class="content letterfont">最后，请接受我们诚挚的邀请。同时也衷心期望您能持续给予我们您宝贵的建议和指教，让我们工作的质量能不断提高与进步，从而最大限度地满足客户对我们的期许，这是我们最大的心愿。</div>
            <div class="content letterfont">顺祝</div>
            <div class="content letterfont">身体健康，万事顺意！</div>
        </div>
        <div class="letterfont tootip">
            以下为您保单的信息：
        </div>
    </div>
</template>
<style scoped>
.content{
    text-indent: 0.8cm;   
}
</style>
