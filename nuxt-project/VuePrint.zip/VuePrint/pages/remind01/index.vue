<template>
    <div>
        <page1></page1>
    </div>
</template>
<script>
import page1 from '@/components/remind01/page1'
export default {
    components: {
        page1
    }
}
</script>
