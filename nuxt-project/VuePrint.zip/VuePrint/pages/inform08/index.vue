<template>
    <div>
        <page1></page1>
        <page2></page2>
    </div>
</template>
<script>
import page1 from '@/components/inform08/page1'
import page2 from '@/components/inform08/page2'
export default {
    components: {
        page1,
        page2
    }
}
</script>
