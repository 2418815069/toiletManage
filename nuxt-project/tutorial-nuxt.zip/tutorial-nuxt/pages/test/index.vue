<template>
  <div>
    <page0></page0>
    <page1></page1>
    <page2></page2>
    <page3></page3>
    <page4></page4>
    <page5></page5>
  </div>
</template>

<script>
  import page0 from './page0'
  import page1 from './page1'
  import page2 from './page2'
  import page3 from './page3'
  import page4 from './page4'
  import page5 from './page5'
  export default {
    components: {
      page0,
      page1,
      page2,
      page3,
      page4,
      page5
    }
  }
</script>

<style>
</style>
