<template>
    <div>{{msg}}</div>
</template>
<script>
export default {
    data(){
        return{
            msg:'bhdakdnx'
        }
    }
}
</script>
