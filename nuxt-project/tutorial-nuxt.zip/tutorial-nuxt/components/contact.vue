<template>
    <div>
        <div>北京百星人寿保险股份有限公司</div>
        <div>地址: 北京市通州区光机电一体化基地嘉创路10号枢密院D3栋</div>
        <div>邮政编码: 101111</div>
        <div>客户服务联系电话: 400-610-5058</div>
        <div>公司网址:www.belstar.com.cn</div>
    </div>
</template>

<style scoped>

</style>
