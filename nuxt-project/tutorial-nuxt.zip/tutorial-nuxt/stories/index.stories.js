/* eslint-disable react/react-in-jsx-scope, react/no-this-in-sfc */

import { storiesOf } from '@storybook/vue';
import { action } from '@storybook/addon-actions';
import { linkTo } from '@storybook/addon-links';
import { withInfo } from 'storybook-addon-vue-info'

import MyButton from './MyButton';
import Welcome from './Welcome';
import belstar from '../components/belstar'
import test from '../pages/test1'
// import App from '../pages/index'
import MyHeader from '../components/MyHeader'
import MyTitle from '../components/MyTitle'
import MyFooter from '../components/MyFooter'
import contact from '../components/contact'
import part1 from '../components/Pages2/part1'
import part2 from '../components/Pages2/part2'
import part3 from '../components/Pages2/part3'
import tableLeft from '../components/Pages3/tableLeft'
import tableRight from '../components/Pages3/tableRight'
import grid from '../components/Pages4/grid'
import * as all from './getalldata.js'
storiesOf('common component', module)
.add('MyHeader', withInfo({
  summary: 'MyHeader for MyComponent'
  })(() => ({
  components: { MyHeader },
  template: '<my-header title="header title"></my-header>'
})))
.add('MyFooter', withInfo({
  summary: 'MyFooter for MyComponent'
  })(() => ({
  components: { MyFooter },
  template: '<my-footer page="2" totelPage="30" printData="2017/10/31">',
})))
.add('MyTitle', withInfo({
  summary: 'MyTitle for MyComponent'
  })(() => ({
  components: { MyTitle },
  template: '<my-title  title="退保手续费率"></my-title>',
})))
.add('belstar', withInfo({
  summary: 'belstar for MyComponent'
  })(() => ({
  components: { belstar },
  template: '<belstar maintitle="百星安康宝年金保险条款" smalltitle="BEIJING BELSTAR" title="保险单">',
})))
.add('contact', withInfo({
  summary: 'contact for MyComponent'
  })(() => ({
  components: { contact },
  template: '<contact></contact>',
})));
storiesOf('page2', module)
.add('part1', withInfo({
  summary: 'part1 for pages'
  })(() => ({
  components: { part1 },
  template: '<part1 :table1="table1" class="part"></part1> ',
  data(){
    return{
      table1: all.table1
    }
  }
})))
.add('part2', withInfo({
  summary: 'part2 for pages'
  })(() => ({
  components: { part2 },
  template: '<part2 :table2="table2" class="part"></part2> ',
  data(){
    return{
      table2: all.table2
    }
  }
})))
.add('part3', withInfo({
  summary: 'part 3for pages'
  })(() => ({
  components: { part3 },
  template: '<part3 :table3="table3" class="part"></part3>',
  data(){
    return{
      table3: all.table3
    }
  }
})));
storiesOf('page3', module)
.add('tableRight', withInfo({
  summary: 'tableRight for pages'
  })(() => ({
  components: { tableRight },
  template: '<table-right :tableright="tableRight"></table-right> ',
  data(){
    return{
      tableRight: all.tableRight
    }
  }
})))
.add('tableLeft', withInfo({
  summary: 'tableLeft for pages'
  })(() => ({
  components: { tableLeft },
  template: '<table-left :tableleft="tableLeft"></table-left>',
  data(){
    return{
      tableLeft: all.tableLeft
    }
  }
})));
storiesOf('page4', module)
.add('grid', withInfo({
  summary: 'grid for pages'
  })(() => ({
  components: { grid },
  template: '<grid :tabledata="table1"></grid> ',
  data(){
    return{
      table1: all.page4.table1
    }
  }
})));
storiesOf('Button', module)
  .add('with text', () => ({
    components: { MyButton },
    template: '<my-button @click="action">Hello Button</my-button>',
    methods: { action: action('clicked') },
  }))
  .add('with JSX', () => ({
    components: { MyButton },
    // eslint-disable-next-line no-unused-vars
    render(h) {
      return <my-button onClick={this.action}>With JSX</my-button>;
    },
    methods: { action: linkTo('clicked') },
  }));
/* eslint-enable react/react-in-jsx-scope */
