import alldata1 from '../data/baodan.json'
import alldata2 from '../data/pagedata.json'
// export let table1 = alldata1[0].table1
export const table1 = alldata1[0].table1
export let table2 = alldata1[0].table2
export let table3 = alldata1[0].table3
export let tableRight = alldata1[0].tableRight
export let tableLeft = alldata1[0].tableLeft
export const page4 = alldata2[0].page4