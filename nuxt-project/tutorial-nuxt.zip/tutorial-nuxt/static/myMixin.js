let myMixin = {
  data() {
    return {
      myTestData: 'myTestData'
    }
  }
}

export default myMixin;
